const express = require("express");
const router = express.Router();
const User = require("../models/users"); // Ensure this path is correct for your User model
const users = require("../models/users");

// Insert a user into the database route
router.post("/add", (req, res) => {
  const { name, email, book, genre, author } = req.body;

  // Check for required fields
  if (!name || !email || !book || !genre || !author) {
    return res
      .status(400)
      .send("All fields are required: name, email, book, genre, author.");
  }

  const user = new User({
    name,
    email,
    book,
    genre,
    author,
  });

  user
    .save()
    .then(() => {
      // Redirect to home page after successful save
      res.redirect("/");
    })
    .catch((error) => {
      console.error("Error saving user:", error.message);
      res.status(500).send("Error saving user: " + error.message);
    });
});

// Render home page
router.get("/", (req, res) => {
  res.render("index", { title: "Home Page" });
});

// Render add users page
router.get("/add", (req, res) => {
  res.render("add_users", { title: "Add Users" });
});

module.exports = router;
